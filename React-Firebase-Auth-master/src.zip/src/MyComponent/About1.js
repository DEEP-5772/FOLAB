import React from 'react'

export default function About1() {
return (
    <>
        
       
<body style={{backgroundImage: "linear-gradient(45deg, purple,green)", height:"689px"}}>
    <div>
        <br/>
        <br/>
    
<span style={{paddingLeft:"50px"}} />
<img src="https://i.ibb.co/562Hw2d/F-removebg-preview.png" alt="Deep Patel" style={{width: "200px", height:"250px", border:"3px solid black", borderRadius:"50%"}}/>   
{/* <img src="https://i.ibb.co/vXFRkkL/Dep.png" alt="Deep Patel" style={{width: "200px", height:"250px", borderRadius:"50%", border:"3px solid black"}}/> */}

<span style={{paddingLeft:"200px"}} />
<img src="https://i.ibb.co/vk703ZS/A.png" alt="Abhishek Patel" style={{width: "200px", height:"250px", border:"3px solid rgb(0,0,0)",  borderRadius:"50%"}}/>

<span  style={{paddingLeft:"200px"}} />
<img src="https://i.ibb.co/zrNhgcL/Dev-new-RBG.png" alt="Dev Patel" style={{width: "200px", height:"250px", border:"3px solid black",paddingLeft:"0px", borderRadius:"50%"}}/>

<span style={{paddingLeft:"200px"}}  >
<img src="https://i.ibb.co/vB3Vr1M/Maitri-new-photo-remove.png" alt="Maitri Trivedi" style={{width: "200px", height:"250px", border:"3px solid black", borderRadius:"50%"}}/>
</span>
{/* </div> */}
</div>

<span style={{color:"white"}}>
    <br/>
    <font style={{FontFamily:'Times new roman', fontSize: 30, paddingLeft:"80px", Color:"red"}}><b>Deep Patel</b></font>
</span>

<span style={{paddingLeft:"220px",color:"white"}}>
    <font style={{FontFamily:'Times new roman', fontSize: 30}}><b>Abhishek Patel</b></font>
</span>

<span style={{paddingLeft:"240px",color:"white"}}>
    <font style={{FontFamily:'Times new roman', fontSize: 30}}><b>Dev Patel</b></font>
</span>

<span style={{paddingLeft:"230px", color:"white"}}>
    <font style={{FontFamily:'Times new roman', fontSize: 30}}><b>Maitri Trivedi</b></font>
</span>

<span style={{}}>
    <br/>
    <font style={{FontFamily:'Times new roman', fontSize: 18, paddingLeft:"90px", Color:"red"}}><b>Web developer</b></font>
</span>

<span style={{paddingLeft:"270px"}}>
    <font style={{FontFamily:'Times new roman', fontSize: 18}}><b>Web developer</b></font>
</span>

<span style={{paddingLeft:"285px"}}>
    <font style={{FontFamily:'Times new roman', fontSize: 18}}><b>Web developer</b></font>
</span>

<span style={{paddingLeft:"260px"}}>
    <font style={{FontFamily:'Times new roman', fontSize: 18}}><b>Web developer</b></font>
</span>

</body>




{/* Name */}
{/* Technical Skills  */}



    </>
)
}
